#include <sys/types.h>
#include <fcntl.h>
#include <poll.h>
#include <stropts.h>
#include <linux/termios.h>

#include "check.h"
#include "serialconfig.h"

void serialconfig(int fd, int speed, int databits, int stopbits, char parity){
    struct termios2 t;
    check(ioctl(fd, TCGETS2, &t), "TCGETS2");
    t.c_cflag = (t.c_cflag & ~CBAUD & ~CSIZE & ~CSTOPB) | BOTHER; // BOTHER (=CBAUDEX | B0)
    switch (databits){
        case 5:
            t.c_cflag |= CS5;
            break;
        case 6:
            t.c_cflag |= CS6;
            break;
        case 7:
            t.c_cflag |= CS7;
            break;
        case 8:
            t.c_cflag |= CS8;
            break;
        default:
            t.c_cflag |= CS8;
    }

    if(stopbits == 2)
        t.c_cflag |= CSTOPB;

    switch(parity){
        case 'n':
        case 'N':
            t.c_cflag &= ~PARENB;
            break;
        case 'o':
        case 'O':
            t.c_cflag = t.c_cflag | PARODD | PARENB;
            break;
        case 'e':
        case 'E':
            t.c_cflag = (t.c_cflag & ~PARODD) | PARENB;
            break;
        default:
    }

    t.c_ispeed = t.c_ospeed = speed;
    check(ioctl(fd, TCSETS2, &t), "TCSETS2");
}

void serialconfig(int fd, int speed, char *bits_parity){
    if(sizeof(bits_parity) != 3){
        printf("Wrong config value %s", bits_parity);
        exit(1);
    }
    serialconfig(fd, speed, atoi(bits_parity[0]), bits_parity[1], atoi(bits_parity[2]);
}
