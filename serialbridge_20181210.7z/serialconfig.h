#ifndef _SERIALCONFIG_H
#define _SERIALCONFIG_H

void serialconfig(int fd, int speed, int databits, int stopbits, char parity);

#endif // _SERIALCONFIG_H
