#ifndef _MB_CRC_H
#define _MB_CRC_H

unsigned short          usMBCRC16( char * pucFrame, unsigned short usLen );

#endif
