#include <sys/types.h>
#include <fcntl.h>
#include <poll.h>
#include <stropts.h>
// #include <linux/termios.h>
#include <termios.h>
// #include <unistd.h>  // UNIX Standard Definitions

#include "check.h"
#include "serialconfig.h"

// void serialconfig(int fd, int speed, int databits, int stopbits, char parity){
//     struct termios2 t;
//     check(ioctl(fd, TCGETS2, &t), "TCGETS2");
//     t.c_cflag = (t.c_cflag & ~CBAUD & ~CSIZE & ~CSTOPB) | BOTHER; // BOTHER (=CBAUDEX | B0)
//     switch (databits){
//         case 5:
//             t.c_cflag &= ~CSIZE;
//             t.c_cflag |= CS5;
//             break;
//         case 6:
//             t.c_cflag &= ~CSIZE;
//             t.c_cflag |= CS6;
//             break;
//         case 7:
//             t.c_cflag &= ~CSIZE;
//             t.c_cflag |= CS7;
//             break;
//         case 8:
//             t.c_cflag &= ~CSIZE;
//             t.c_cflag |= CS8;
//             break;
//         default:
//             t.c_cflag &= ~CSIZE;
//             t.c_cflag |= CS8;
//     }

//     if(stopbits == 2)
//         t.c_cflag |= CSTOPB;
//     else
//         t.c_cflag &= ~CSTOPB;

//     switch(parity){
//         case 'o':
//         case 'O':
//             t.c_cflag |= (PARENB | PARODD);
//             // t.c_cflag |= PARODD;
//             break;
//         case 'e':
//         case 'E':
//             t.c_cflag |= PARENB;
//             t.c_cflag &= ~PARODD;
//             break;
//         case ' ':
//             t.c_cflag &= ~PARENB;
//             t.c_cflag &= ~CSTOPB;
//         case 'n':
//         case 'N':
//         default:
//             t.c_cflag &= ~PARENB;
//             t.c_cflag &= ~PARODD;
//     }

//     t.c_ispeed = t.c_ospeed = speed;
//     check(ioctl(fd, TCSETS2, &t), "TCSETS2");
//     printf("BaudRate = %d, Databits = %d, Stopbits = %d, Parity = %c\n", speed, databits, stopbits, parity);
// }

void serialconfig(int fd, int speed, int databits, int stopbits, char parity){
    //struct termios2 t;
    unsigned int baudrate = 0;
    struct termios SerialPortSettings;	// Create the structure
    tcgetattr(fd, &SerialPortSettings);	// Get the current attributes of the Serial port
    // SerialPortSettings.c_cflag = (SerialPortSettings.c_cflag & ~CBAUD & ~CSIZE & ~CSTOPB) | BOTHER; // BOTHER (=CBAUDEX | B0)
    
    // SerialPortSettings.c_cflag |= CREAD|CLOCAL;
    // SerialPortSettings.c_lflag &= ~(ICANON|ECHO|ECHOE|ECHOK|ECHONL|ISIG);
    // SerialPortSettings.c_iflag &= ~(INPCK|IGNPAR|PARMRK|ISTRIP|ICRNL|IXANY);
    // SerialPortSettings.c_oflag &= ~OPOST;

    // SerialPortSettings.c_cflag &= ~CNEW_RTSCTS;       // No Hardware flow Control
    SerialPortSettings.c_cflag |= CREAD | CLOCAL; // Enable receiver,Ignore Modem Control lines
    SerialPortSettings.c_iflag &= ~(IXON | IXOFF | IXANY);          // Disable XON/XOFF flow control both i/p and o/p
    SerialPortSettings.c_iflag &= ~(ICANON | ECHO | ECHOE | ISIG);  // Non Cannonical mode
    SerialPortSettings.c_iflag |= (INPCK | ISTRIP);
    SerialPortSettings.c_oflag &= ~OPOST;// No Output Processing

    switch(speed){
        case 1200:
            baudrate = B1200;
            break;
        case 2400:
            baudrate = B2400;
            break;
        case 4800:
            baudrate = B4800;
            break;
        case 9600:
            baudrate = B9600;
            break;
        case 19200:
            baudrate = B19200;
            break;
        case 38400:
            baudrate = B38400;
            break;
        case 57600:
            baudrate = B57600;
            break;
        case 115200:
            baudrate = B115200;
            break;
    }

#ifdef CBAUD
    SerialPortSettings &= ~CBAUD;
    SerialPortSettings |= baudrate;
#else
    cfsetispeed(&SerialPortSettings, baudrate); // Set Read  Speed as baudrate
    cfsetospeed(&SerialPortSettings, baudrate); // Set Write Speed as baudrate
#endif

    switch (databits){
        case 5:
            SerialPortSettings.c_cflag &= ~CSIZE;
            SerialPortSettings.c_cflag |= CS5;
            break;
        case 6:
            SerialPortSettings.c_cflag &= ~CSIZE;
            SerialPortSettings.c_cflag |= CS6;
            break;
        case 7:
            SerialPortSettings.c_cflag &= ~CSIZE;
            SerialPortSettings.c_cflag |= CS7;
            break;
        case 8:
            SerialPortSettings.c_cflag &= ~CSIZE;
            SerialPortSettings.c_cflag |= CS8;
            break;
        default:
            SerialPortSettings.c_cflag &= ~CSIZE;
            SerialPortSettings.c_cflag |= CS8;
    }

    if(stopbits == 2 && databits != 5)
        SerialPortSettings.c_cflag |= CSTOPB;
    else
        SerialPortSettings.c_cflag &= ~CSTOPB;

    switch(parity){
        case 'o':
        case 'O':
            SerialPortSettings.c_cflag |= (PARENB | PARODD);
            break;
        case 'e':
        case 'E':
            SerialPortSettings.c_cflag &= ~PARODD;
            SerialPortSettings.c_cflag |= PARENB;
            break;
        // case ' ':  // does't support by posix
        //     SerialPortSettings.c_cflag &= ~PARENB;
        //     SerialPortSettings.c_cflag &= ~CSTOPB;
        case 'n':
        case 'N':
        default:
            SerialPortSettings.c_cflag &= ~PARENB;
            SerialPortSettings.c_cflag &= ~PARODD;
    }

    // TCSANOW
    if((tcsetattr(fd, TCSAFLUSH, &SerialPortSettings)) != 0) // Set the attributes to the termios structure
		printf("ERROR! in Setting attributes\n");
	else
        printf("BaudRate = %d, Databits = %d, Stopbits = %d, Parity = %c\n", speed, databits, stopbits, parity);
}


void serialset(int fd, int speed, char *cflag){
    if(sizeof(cflag) != 4){
        printf("Wrong config value %s, lenght %d\n", cflag, sizeof(cflag));
        exit(1);
    }

    char databits = cflag[0];
    char parity = cflag[1];
    char stopbits = cflag[2];
    printf("Serial Config: %d, %d, %d, %c\n", speed, atoi(&databits), atoi(&stopbits), parity);
    serialconfig(fd, speed, atoi(&databits), atoi(&stopbits), parity);
}
