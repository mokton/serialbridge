#ifndef _SERIALCONFIG_H
#define _SERIALCONFIG_H

void serialconfig(int fd, int speed, int databits, int stopbits, char parity);
void serialset(int fd, int speed, char *bits_parity);
#endif // _SERIALCONFIG_H
